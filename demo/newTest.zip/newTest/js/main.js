var config = {
    radius: 300
}

var main = document.getElementById('main');

var scene = new THREE.Scene();

var renderer = new THREE.WebGLRenderer({
    antialias: true
});
renderer.setSize(window.innerWidth, window.innerHeight);

var camera = new THREE.PerspectiveCamera(25, window.innerWidth / window.innerHeight, 1, 20000);
camera.position.z = 1900;
camera.position.y = 0;

main.appendChild(renderer.domElement);


/** earth **/

var earthGeo = new THREE.SphereGeometry(config.radius, 100, 50);
var earth = THREE.SceneUtils.createMultiMaterialObject(earthGeo, [
    new THREE.MeshPhongMaterial({
        color: 0xfefefe,
        transparent: true,
        opacity: 0.5,
        combine: THREE.MultiplyOperation,
        name: 'earth1'
    }),
    new THREE.MeshBasicMaterial({
        color: 0x002A52,
        transparent: true,
        // depthWrite:false,
        // depthTest:false,
        opacity: 0.8,
        blending: THREE.AdditiveBlending,
        side: THREE.DoubleSide,
        name: 'earth2'
    }),
    new THREE.MeshBasicMaterial({
        color: 0xf0f0f0,
        transparent: true,
        opacity: 0.1,
        blending: THREE.AdditiveBlending,
        wireframe: true,
        side: THREE.FrontSide,
        name: 'earth3'
    }),
]);
earth.name = 'earth';
console.log(earth)
scene.add(earth);
/** end earth **/

/* light */
var backgroundLight = new THREE.HemisphereLight(0x002A52, 0x000000, 7);
scene.add(backgroundLight);
/* end light */

/* map */
var mapGeomerty = new THREE.Geometry();

//country bands
var mapSwitch = '';
if (mapSwitch == 'mine') {
    var countrys = world.features;
    for (var i in countrys) {
        var countryGeometry = countrys[i].geometry;

        if (countryGeometry.type === 'Polygon') {
            for (j in countryGeometry.coordinates) {
                var coors = countryGeometry.coordinates[j];
                getTheLatlog(coors)
            }
        } else {
            for (var j = 0; j < countryGeometry.coordinates.length; j++) {
                for (var k = 0; k < countryGeometry.coordinates[j].length; k++) {
                    var coors = countryGeometry.coordinates[j][k];
                    getTheLatlog(coors)
                }
            }
        }
    };

    function getTheLatlog(coors) {
        for (var i = 0; i < coors.length; i++) {
            pushVert(coors[i][0], coors[i][1]);
        }
    };
    //
    function pushVert(lat, log) {
        mapGeomerty.vertices.push(latlogToVec3(lat, log));
    };

    var mapmaterial = new THREE.PointCloudMaterial({
        size: 3,
        color: 'yellow',
    });
    var map = new THREE.PointCloud(mapGeomerty, mapmaterial);

    function latlogToVec3(lat, log) {
        var radius = config.radius + 5;
        var y = radius * Math.sin(log * Math.PI / 180);
        var newRadius = radius * Math.cos(log * Math.PI / 180);

        var x = newRadius * Math.sin(lat * Math.PI / 180);
        var z = newRadius * Math.cos(lat * Math.PI / 180);

        return new THREE.Vector3(x, y, z);
    }

    earth.add(map);
} else {
    var test = true;
    var count = 0;
    for (var name in country_data) {
        geometry = new Tessalator3D(country_data[name], 0);

        var continents = ["EU", "AN", "AS", "OC", "SA", "AF", "NA"];
        var color = new THREE.Color(0xff0000);
        color.setHSL(continents.indexOf(country_data[name].data.cont) * (1 / 7), Math.random() * 0.25 + 0.65, Math.random() / 2 + 0.25);
        mesh = country_data[name].mesh = new THREE.Mesh(geometry, new THREE.MeshLambertMaterial({
            color: color,
            // opacity: 0.9,
            // side: THREE.DoubleSide,
            // blending: THREE.AdditiveBlending,
            // transparent: true
        }));
        count++;
        if (count > 200) {
            test = false;
        }
        mesh.name = "land";
        mesh.userData.country = name;
        mesh.scale.x = 305;
        mesh.scale.y = 305;
        mesh.scale.z = 305;
        // mesh.position.z=900;
        earth.add(mesh);
    }
}
/* end map */

/*****/
window.addEventListener('mousemove', onMouseMove, false);
var mouse = new THREE.Vector3();
var raycaster = new THREE.Raycaster();

function onMouseMove(event) {
    mouse.x = (event.clientX / window.innerWidth) * 2 - 1;
    mouse.y = -(event.clientY / window.innerHeight) * 2 + 1;

    raycaster.setFromCamera(mouse, camera);
    var intersects = raycaster.intersectObject(scene, true);

    if (intersects[0] && intersects[0].object.name === "land") {
        console.log('xxx')
        intersects[0].object.scale.multiplyScalar(1.01);
    }

};
/*****/


function readen() {
    renderer.clear();
    renderer.render(scene, camera);
    requestAnimationFrame(readen);
    earth.rotateY(0.001)
}

requestAnimationFrame(readen);
